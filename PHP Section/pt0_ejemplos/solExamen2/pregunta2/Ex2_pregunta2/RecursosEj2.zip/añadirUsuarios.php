<?php
require 'Usuario.php';

Usuario::crearUsuario('pepe', '123_pepe_321');
Usuario::crearUsuario('pepita', '123_pepita_321');
Usuario::crearUsuario('crackeable', 'abcde');