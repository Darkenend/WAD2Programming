<?php
/**
 * Los vínculos cambian por llamadas a las funciones JavaScript correspondientes
 * El nombre del usuario aparecerá una vez que el usuario haya hecho login (JavaScript)
 */
?>
<header>
    <span id="cabUsuario"></span>
    <a href="#" onclick="cargarCategorias();">Home</a>
    <a href="#" onclick="cargarCarrito();">Carrito</a>
    <a href="#" onclick="cerrarSesionUnaPagina();">Cerrar sesión</a>
    <?php
        if ($_SESSION['usuario']['rol']) {
            echo "<a href='#' onclick='cargarZonaAdmin();'>Zona Admin</a>";
        }
    ?>
</header>